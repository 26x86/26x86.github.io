NextCore prebuilt EFI development package

Normal macOS startup: NOT_READY. Physical desktop boot: UNVERIFIED.
Compilation and archive validation do not prove firmware compatibility or macOS boot.

EFI/BOOT/BOOTX64.EFI is the baseline x86_64 UEFI application, built without
selected diagnostic features. EFI/OC/config.plist is its public configuration
path. The supplied empty configuration selects no guest; the baseline displays
the configuration recovery screen. Enter retries this same configuration and
Esc returns to firmware with NOT_FOUND. Required display or input failures return
their actual error. Supply a deliberate, supported entry configuration before
attempting a target; this package cannot install macOS.

Use a separate FAT-formatted removable test volume. The EFI directory is relative
to that volume's root. Preserve your existing system EFI and recovery path; this
archive performs no installation or NVRAM changes. It contains no Apple payload.

diagnostics/NXARMJIT.efi is a separate mapped ARM execution diagnostic, NOT the
normal boot entry. Do not rename it BOOTX64.EFI. Launch it explicitly only with an
authored or locally supplied configuration accepted by the pinned trace contract.
The diagnostic requires its own kernel/DeviceTree/configuration, which are not
included here. Profile selection is not evidence of an original-image entry ABI.

Private assembly metadata, public code pins, commands, tools and hashes: manifest.json.
Archive download hash: prebuiltefi.json beside the ZIP on the website.
Public capability status: https://26x86.github.io/progress/
Distribution notices and third-party source access: LICENSES.txt.
This product includes software developed by Dortania, OpenCore Legacy Patcher contributors, and the 26x86 project.

Private assembly metadata (not a publicly downloadable source checkout):
https://github.com/26x86/26x86.git @ 3d3a434dfc9f84dcc1c34a2257f8cf7ceaafd99c
The assembly revision pins build layout and gitlinks. The complete build
assembly is private; public code pins do not make that assembly public.

Primary EFI source: https://github.com/26x86/Nextcore-EFI.git @ df2c15b8c83664042c33daa274f550158308a752 (nextcore/crates/nextcore-efi)

Public code sources (exact immutable module revisions):
nextcore-apls: https://github.com/26x86/Nextcore-APLS.git @ 9b6ccaa421f668fdb212ccd14969002f6196a18f (nextcore/crates/nextcore-apls)
nextcore-core: https://github.com/26x86/Nextcore-Core.git @ 4ae6e9aff31be93cf570b56975b711902f3fb7e7 (nextcore/crates/nextcore-core)
nextcore-efi: https://github.com/26x86/Nextcore-EFI.git @ df2c15b8c83664042c33daa274f550158308a752 (nextcore/crates/nextcore-efi)
nextcore-gpu: https://github.com/26x86/Nextcore-GPU.git @ eaab9fcfded3a8ee298453397790f13edace5694 (nextcore/crates/nextcore-gpu)
nextcore-hal: https://github.com/26x86/Nextcore-HAL.git @ 9c1cd8dfff33478e32668c5cd181dd094ec2881b (nextcore/crates/nextcore-hal)
nextcore-ise: https://github.com/26x86/Nextcore-ISE.git @ 778473fd9c43d7ba3a4721852f838be996fed45d (nextcore/crates/nextcore-ise)
nextcore-tool: https://github.com/26x86/Nextcore-Tool.git @ 9e6222a69d2f62490139c477d6e217a28e3af323 (nextcore/crates/nextcore-tool)
